/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.loginsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginSystemTest {

    Validator validator = new Validator();

    // ================= ASSERT EQUALS =================

    @Test
    public void testUsernameIncorrectlyFormatted_ReturnsFalse() {
        boolean result = validator.isValidUsername("kyle");
        assertEquals(false, result);
    }

    @Test
    public void testPasswordMeetsRequirements_ReturnsTrue() {
        boolean result = validator.isValidPassword("Ch&&sec@ke99!");
        assertEquals(true, result);
    }

    @Test
    public void testPasswordDoesNotMeetRequirements_ReturnsFalse() {
        boolean result = validator.isValidPassword("password");
        assertEquals(false, result);
    }

    @Test
    public void testCellNumberCorrectlyFormatted_ReturnsTrue() {
        boolean result = validator.isValidPhone("+27838968976");
        assertEquals(true, result);
    }

    @Test
    public void testCellNumberIncorrectlyFormatted_ReturnsFalse() {
        boolean result = validator.isValidPhone("08966553");
        assertEquals(false, result);
    }

    // ================= ASSERT TRUE / FALSE =================

    @Test
    public void testLoginSuccessful() {
        User user = new User("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        boolean result = user.authenticate("kyl_1", "Password1!");
        assertTrue(result);
    }

    @Test
    public void testLoginFailed() {
        User user = new User("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        boolean result = user.authenticate("kyl_1", "wrongPass");
        assertFalse(result);
    }

    @Test
    public void testUsernameCorrectlyFormatted_ReturnsTrue() {
        boolean result = validator.isValidUsername("kyl_1");
        assertTrue(result);
    }
}