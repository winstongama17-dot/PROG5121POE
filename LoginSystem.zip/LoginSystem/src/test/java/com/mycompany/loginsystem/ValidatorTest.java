/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.loginsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ndivhuwo
 */
public class ValidatorTest {
    
    public ValidatorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of isValidUsername method, of class Validator.
     */
    @Test
    public void testIsValidUsername() {
        System.out.println("isValidUsername");
        String u = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isValidUsername(u);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidPassword method, of class Validator.
     */
    @Test
    public void testIsValidPassword() {
        System.out.println("isValidPassword");
        String p = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isValidPassword(p);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isValidPhone method, of class Validator.
     */
    @Test
    public void testIsValidPhone() {
        System.out.println("isValidPhone");
        String ph = "";
        Validator instance = new Validator();
        boolean expResult = false;
        boolean result = instance.isValidPhone(ph);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
